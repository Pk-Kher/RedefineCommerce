import React from 'react';

function CheckBoxAction({ selectedFlatRows, setOpenDeleteModal, setBrand }) {
    return (
        <>

        </>
    )
}

export default CheckBoxAction;