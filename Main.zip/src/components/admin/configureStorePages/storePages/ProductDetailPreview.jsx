/*Component Name: ProductDetailPreview
Component Functional Details: User can create or update ProductDetailPreview master details from here.
Created By: chandan
Created Date: <Creation Date>
Modified By: chandan
Modified Date: <Modified Date> */

import React from 'react';

const ProductDetailPreview = () => {
    return (
        <>
            <iframe className="w-full min-h-screen mx-auto" src="http://ystore.us/HTML/RedefineCommerce/Admin/store-pro-detail.html" frameBorder={0} />
        </>
    );
};

export default ProductDetailPreview;
