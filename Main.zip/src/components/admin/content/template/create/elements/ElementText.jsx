/*Component Name: ElementText
Component Functional Details: Element for Component Background  
Created By: Vikas Patel
Created Date: 07/07/2022
Modified By: <Modified By Name>
Modified Date: <Modified Date> */

import React from 'react';

const ElementText = () => {
    return (
        <>
            <div className="relative border-b border-neutral-00">ElementText</div>
        </>
    );
};

export default ElementText;
